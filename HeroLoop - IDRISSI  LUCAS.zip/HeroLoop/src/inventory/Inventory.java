package inventory;

import collectable.Item;

public class Inventory { // Phase 2
	private Item helmet;
	private Item armor;
	private Item sword;
	private Item ring;
	private Item amulet;
	
	public Inventory() {
		this.helmet = null;
		this.armor = null;
		this.sword = null;
		this.ring = null;
		this.amulet = null;
	}

}
