package collectable;

public enum CardState { // Represents the three different states (types) a card can have.
	ROAD, 
	ROADSIDE,
	LANDSCAPE;
}
