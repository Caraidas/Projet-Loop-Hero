package data;

public record GridPosition(int line, int column) { // represents a position on a grid

}
