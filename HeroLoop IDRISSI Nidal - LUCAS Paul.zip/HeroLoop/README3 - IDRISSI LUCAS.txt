[IDRISSI Nidal - LUCAS Paul]


1 - Ce qui à été implémenté :

	- Tous ce qui à été demandé dans la phase 3 à été implémenter.
	- Nous avons ajouter deux statistiques du jeu original (pure damage, damage to all)
	- Nous avons aussi mis les synergies de certains batiments
	- Des animations ont été implémentées pour savoir qui attaque et reçoit les coups

2 - Organisation du programme :

	- Il y a eu une réforme de ce comment on gère les cartes car l'ancienne ne nous permettait pas d'implémenter les nouvelles cartes
	- Nous avons implémenter un record ressource pour gérer les ressources et leurs implémentations

3 - Choix techniques :

	- Il y a désormait une classe par carte car les cartes ayant toutes des effets unique, nous avons choisi donc de faire comme ceci
	- Nous avons choisi de mettre plusieurs boucles qui sont choisis aléatoirement lorsqu'une partie est lancé
	- On peut sauvegarder à n'importequ'elle moment (sauf pendant les combats)

4 - Problèmes rencontrés :

	- Aucun problème n'as été rencontré.

Merci d'avoir lu :)