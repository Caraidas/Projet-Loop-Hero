[IDRISSI Nidal - LUCAS Paul]


1 - Ce qui à été implémenté :

	- Tous ce qui à été demandé dans la phase 2 à été implémenter.

2 - Organisation du programme :

	- Les combats sont gérés dans la classe BattleData
	- Les classes s'occupant de l'inventaire sont Inventory et Item.

3 - Choix techniques :

	- Lors des combats, nous arretons le temps afin que le heros ne se déplace pas.
	- L'ordre d'attaque lors d'un combat est : player puis tout les monstre l'un après l'autre.
	- Comme dans le vrai jeu, le héros choisi une cible au hasard et attaque cette cible chaque tour jusqu'à sa mort.

4 - Problèmes rencontrés :

	- Aucun problème n'as été rencontré.

Merci d'avoir lu :)